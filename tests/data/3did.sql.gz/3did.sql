-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: aloy-dbsrv    Database: 3did_2022_01
-- ------------------------------------------------------
-- Server version	5.7.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DDI1`
--

DROP TABLE IF EXISTS `DDI1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;

--
-- Table structure for table `DDI1`
--

DROP TABLE IF EXISTS `DDI1`;
CREATE TABLE `DDI1` (
  `domain1` varchar(30) NOT NULL DEFAULT '',
  `oDB1` set('Pfam','SMART','SCOP') NOT NULL DEFAULT '',
  `domain2` varchar(30) NOT NULL DEFAULT '',
  `oDB2` set('Pfam','SMART','SCOP') NOT NULL DEFAULT '',
  `classification` varchar(20) DEFAULT NULL,
  `decision` char(1) DEFAULT 'a',
  `InterPreTS` double DEFAULT NULL,
  `picFile` varchar(20) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`domain1`,`oDB1`,`domain2`,`oDB2`),
  FULLTEXT KEY `comment` (`comment`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;




DROP TABLE IF EXISTS `DMI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;

--
-- Dumping data for table `DDI1`
--

LOCK TABLES `DDI1` WRITE;
INSERT INTO `DDI1` VALUES ('WD40','Pfam','WD40','Pfam',NULL,'a',NULL,NULL,NULL),('PK_Tyr_Ser-Thr','Pfam','PK_Tyr_Ser-Thr','Pfam',NULL,'a',NULL,NULL,NULL),('FKBP_C','Pfam','FKBP_C','Pfam',NULL,'a',NULL,NULL,NULL),('fn3','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('Metallophos','Pfam','Metallophos','Pfam',NULL,'a',NULL,NULL,NULL),('I-set','Pfam','I-set','Pfam',NULL,'a',NULL,NULL,NULL),('Sushi','Pfam','Sushi','Pfam',NULL,'a',NULL,NULL,NULL),('Arm','Pfam','Arm','Pfam',NULL,'a',NULL,NULL,NULL),('Ig_3','Pfam','Ig_3','Pfam',NULL,'a',NULL,NULL,NULL),('I-set','Pfam','Ig_3','Pfam',NULL,'a',NULL,NULL,NULL),('DEAD','Pfam','DEAD','Pfam',NULL,'a',NULL,NULL,NULL),('SET','Pfam','SET','Pfam',NULL,'a',NULL,NULL,NULL),('AAA','Pfam','AAA','Pfam',NULL,'a',NULL,NULL,NULL),('SET','Pfam','WD40','Pfam',NULL,'a',NULL,NULL,NULL),('Ig_3','Pfam','I-set','Pfam',NULL,'a',NULL,NULL,NULL),('SET','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('I-set','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('WD40','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('FKBP_C','Pfam','PK_Tyr_Ser-Thr','Pfam',NULL,'a',NULL,NULL,NULL),('FKBP_C','Pfam','Metallophos','Pfam',NULL,'a',NULL,NULL,NULL),('PK_Tyr_Ser-Thr','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('Ig_3','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('fn3','Pfam','I-set','Pfam',NULL,'a',NULL,NULL,NULL);
UNLOCK TABLES;

--
-- Table structure for table `Domain`
--

DROP TABLE IF EXISTS `Domain`;
CREATE TABLE `Domain` (
  `Name` varchar(30) NOT NULL DEFAULT '',
  `origDB` set('Pfam','SMART','SCOP') NOT NULL DEFAULT '',
  `picFile` varchar(20) DEFAULT NULL,
  `comment` text,
  `Pfam_id` varchar(20) DEFAULT NULL,
  `SCOPLink` varchar(20) DEFAULT NULL,
  `CATHLink` varchar(20) DEFAULT NULL,
  `SMARTLink` varchar(20) DEFAULT NULL,
  `added` date DEFAULT NULL,
  PRIMARY KEY (`Name`,`origDB`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;




DROP TABLE IF EXISTS `GO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;

--
-- Dumping data for table `Domain`
--

LOCK TABLES `Domain` WRITE;
INSERT INTO `Domain` VALUES ('WD40','Pfam',NULL,NULL,'PF00400.35',NULL,NULL,NULL,'2022-06-17'),('PK_Tyr_Ser-Thr','Pfam',NULL,NULL,'PF07714.20',NULL,NULL,NULL,'2022-06-17'),('AAA','Pfam',NULL,NULL,'PF00004.32',NULL,NULL,NULL,'2022-06-17'),('Metallophos','Pfam',NULL,NULL,'PF00149.31',NULL,NULL,NULL,'2022-06-17'),('FKBP_C','Pfam',NULL,NULL,'PF00254.31',NULL,NULL,NULL,'2022-06-17'),('SET','Pfam',NULL,NULL,'PF00856.31',NULL,NULL,NULL,'2022-06-17'),('I-set','Pfam',NULL,NULL,'PF07679.19',NULL,NULL,NULL,'2022-06-17'),('Ig_3','Pfam',NULL,NULL,'PF13927.9',NULL,NULL,NULL,'2022-06-17'),('DEAD','Pfam',NULL,NULL,'PF00270.32',NULL,NULL,NULL,'2022-06-17'),('Sushi','Pfam',NULL,NULL,'PF00084.23',NULL,NULL,NULL,'2022-06-17'),('fn3','Pfam',NULL,NULL,'PF00041.24',NULL,NULL,NULL,'2022-06-17'),('Arm','Pfam',NULL,NULL,'PF00514.26',NULL,NULL,NULL,'2022-06-17');
UNLOCK TABLES;
