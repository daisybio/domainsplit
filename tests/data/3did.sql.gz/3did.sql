-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: aloy-dbsrv    Database: 3did_2022_01
-- ------------------------------------------------------
-- Server version	5.7.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DDI1`
--

DROP TABLE IF EXISTS `DDI1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;

--
-- Table structure for table `DDI1`
--

DROP TABLE IF EXISTS `DDI1`;
CREATE TABLE `DDI1` (
  `domain1` varchar(30) NOT NULL DEFAULT '',
  `oDB1` set('Pfam','SMART','SCOP') NOT NULL DEFAULT '',
  `domain2` varchar(30) NOT NULL DEFAULT '',
  `oDB2` set('Pfam','SMART','SCOP') NOT NULL DEFAULT '',
  `classification` varchar(20) DEFAULT NULL,
  `decision` char(1) DEFAULT 'a',
  `InterPreTS` double DEFAULT NULL,
  `picFile` varchar(20) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`domain1`,`oDB1`,`domain2`,`oDB2`),
  FULLTEXT KEY `comment` (`comment`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;




DROP TABLE IF EXISTS `DMI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;

--
-- Dumping data for table `DDI1`
--

LOCK TABLES `DDI1` WRITE;
INSERT INTO `DDI1` VALUES ('C1-set','Pfam','C1-set','Pfam',NULL,'a',NULL,NULL,NULL),('Ras','Pfam','Ras','Pfam',NULL,'a',NULL,NULL,NULL),('Histone','Pfam','Histone','Pfam',NULL,'a',NULL,NULL,NULL),('Lectin_C','Pfam','Lectin_C','Pfam',NULL,'a',NULL,NULL,NULL),('WD40','Pfam','WD40','Pfam',NULL,'a',NULL,NULL,NULL),('PK_Tyr_Ser-Thr','Pfam','PK_Tyr_Ser-Thr','Pfam',NULL,'a',NULL,NULL,NULL),('C1-set','Pfam','MHC_I','Pfam',NULL,'a',NULL,NULL,NULL),('MHC_I','Pfam','MHC_I','Pfam',NULL,'a',NULL,NULL,NULL),('Pkinase','Pfam','Pkinase','Pfam',NULL,'a',NULL,NULL,NULL),('VWA','Pfam','VWA','Pfam',NULL,'a',NULL,NULL,NULL),('FKBP_C','Pfam','FKBP_C','Pfam',NULL,'a',NULL,NULL,NULL),('C2','Pfam','C2','Pfam',NULL,'a',NULL,NULL,NULL),('ubiquitin','Pfam','ubiquitin','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_2','Pfam','Ank_2','Pfam',NULL,'a',NULL,NULL,NULL),('LRR_8','Pfam','LRR_8','Pfam',NULL,'a',NULL,NULL,NULL),('DEAD','Pfam','Helicase_C','Pfam',NULL,'a',NULL,NULL,NULL),('F5_F8_type_C','Pfam','F5_F8_type_C','Pfam',NULL,'a',NULL,NULL,NULL),('ig','Pfam','ig','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_2','Pfam','Ank_4','Pfam',NULL,'a',NULL,NULL,NULL),('Trypsin','Pfam','Trypsin','Pfam',NULL,'a',NULL,NULL,NULL),('fn3','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('Ion_trans','Pfam','Ion_trans','Pfam',NULL,'a',NULL,NULL,NULL),('Metallophos','Pfam','Metallophos','Pfam',NULL,'a',NULL,NULL,NULL),('PK_Tyr_Ser-Thr','Pfam','SH2','Pfam',NULL,'a',NULL,NULL,NULL),('UQ_con','Pfam','UQ_con','Pfam',NULL,'a',NULL,NULL,NULL),('Actin','Pfam','Actin','Pfam',NULL,'a',NULL,NULL,NULL),('PK_Tyr_Ser-Thr','Pfam','Pkinase','Pfam',NULL,'a',NULL,NULL,NULL),('TED_complement','Pfam','VWA','Pfam',NULL,'a',NULL,NULL,NULL),('PDZ','Pfam','PDZ','Pfam',NULL,'a',NULL,NULL,NULL),('UQ_con','Pfam','ubiquitin','Pfam',NULL,'a',NULL,NULL,NULL),('I-set','Pfam','I-set','Pfam',NULL,'a',NULL,NULL,NULL),('Sushi','Pfam','Sushi','Pfam',NULL,'a',NULL,NULL,NULL),('Lectin_C','Pfam','VWA','Pfam',NULL,'a',NULL,NULL,NULL),('Arm','Pfam','Arm','Pfam',NULL,'a',NULL,NULL,NULL),('MHC_I','Pfam','ig','Pfam',NULL,'a',NULL,NULL,NULL),('Cadherin','Pfam','Cadherin','Pfam',NULL,'a',NULL,NULL,NULL),('SH2','Pfam','SH2','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_2','Pfam','Pkinase','Pfam',NULL,'a',NULL,NULL,NULL),('Ig_3','Pfam','Ig_3','Pfam',NULL,'a',NULL,NULL,NULL),('Ig_3','Pfam','ig','Pfam',NULL,'a',NULL,NULL,NULL),('I-set','Pfam','Ig_3','Pfam',NULL,'a',NULL,NULL,NULL),('Sushi','Pfam','TED_complement','Pfam',NULL,'a',NULL,NULL,NULL),('ABC_tran','Pfam','ABC_tran','Pfam',NULL,'a',NULL,NULL,NULL),('I-set','Pfam','LRR_8','Pfam',NULL,'a',NULL,NULL,NULL),('I-set','Pfam','ig','Pfam',NULL,'a',NULL,NULL,NULL),('LRR_8','Pfam','ig','Pfam',NULL,'a',NULL,NULL,NULL),('Pkinase','Pfam','PK_Tyr_Ser-Thr','Pfam',NULL,'a',NULL,NULL,NULL),('DEAD','Pfam','DEAD','Pfam',NULL,'a',NULL,NULL,NULL),('C1-set','Pfam','ig','Pfam',NULL,'a',NULL,NULL,NULL),('SET','Pfam','SET','Pfam',NULL,'a',NULL,NULL,NULL),('Lectin_C','Pfam','MHC_I','Pfam',NULL,'a',NULL,NULL,NULL),('Helicase_C','Pfam','SNF2-rel_dom','Pfam',NULL,'a',NULL,NULL,NULL),('7tm_1','Pfam','7tm_1','Pfam',NULL,'a',NULL,NULL,NULL),('Actin','Pfam','Metallophos','Pfam',NULL,'a',NULL,NULL,NULL),('ubiquitin','Pfam','UQ_con','Pfam',NULL,'a',NULL,NULL,NULL),('AAA','Pfam','AAA','Pfam',NULL,'a',NULL,NULL,NULL),('EGF','Pfam','EGF','Pfam',NULL,'a',NULL,NULL,NULL),('TED_complement','Pfam','TED_complement','Pfam',NULL,'a',NULL,NULL,NULL),('Ldl_recept_a','Pfam','Ldl_recept_a','Pfam',NULL,'a',NULL,NULL,NULL),('SET','Pfam','WD40','Pfam',NULL,'a',NULL,NULL,NULL),('Actin','Pfam','Pkinase','Pfam',NULL,'a',NULL,NULL,NULL),('SH2','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('Ig_3','Pfam','I-set','Pfam',NULL,'a',NULL,NULL,NULL),('Ras','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('SET','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('I-set','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('fn3','Pfam','Pkinase','Pfam',NULL,'a',NULL,NULL,NULL),('C1-set','Pfam','Lectin_C','Pfam',NULL,'a',NULL,NULL,NULL),('Sushi','Pfam','Trypsin','Pfam',NULL,'a',NULL,NULL,NULL),('Helicase_C','Pfam','Helicase_C','Pfam',NULL,'a',NULL,NULL,NULL),('SNF2-rel_dom','Pfam','SNF2-rel_dom','Pfam',NULL,'a',NULL,NULL,NULL),('I-set','Pfam','Pkinase','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_4','Pfam','Pkinase','Pfam',NULL,'a',NULL,NULL,NULL),('Trypsin','Pfam','VWA','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_2','Pfam','Ras','Pfam',NULL,'a',NULL,NULL,NULL),('fn3','Pfam','SH2','Pfam',NULL,'a',NULL,NULL,NULL),('Ldl_recept_a','Pfam','Sushi','Pfam',NULL,'a',NULL,NULL,NULL),('Ldl_recept_a','Pfam','Trypsin','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_2','Pfam','I-set','Pfam',NULL,'a',NULL,NULL,NULL),('Pkinase','Pfam','Ras','Pfam',NULL,'a',NULL,NULL,NULL),('EGF','Pfam','Lectin_C','Pfam',NULL,'a',NULL,NULL,NULL),('C1-set','Pfam','Ig_3','Pfam',NULL,'a',NULL,NULL,NULL),('ig','Pfam','I-set','Pfam',NULL,'a',NULL,NULL,NULL),('LRR_8','Pfam','VWA','Pfam',NULL,'a',NULL,NULL,NULL),('Histone','Pfam','SNF2-rel_dom','Pfam',NULL,'a',NULL,NULL,NULL),('Arm','Pfam','Ras','Pfam',NULL,'a',NULL,NULL,NULL),('WD40','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('Pkinase','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('Actin','Pfam','I-set','Pfam',NULL,'a',NULL,NULL,NULL),('ig','Pfam','Ig_3','Pfam',NULL,'a',NULL,NULL,NULL),('Pkinase','Pfam','ubiquitin','Pfam',NULL,'a',NULL,NULL,NULL),('EGF','Pfam','Sushi','Pfam',NULL,'a',NULL,NULL,NULL),('Histone','Pfam','ubiquitin','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_4','Pfam','Ras','Pfam',NULL,'a',NULL,NULL,NULL),('LRR_8','Pfam','SH2','Pfam',NULL,'a',NULL,NULL,NULL),('FKBP_C','Pfam','PK_Tyr_Ser-Thr','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_4','Pfam','Ank_4','Pfam',NULL,'a',NULL,NULL,NULL),('7tm_1','Pfam','WD40','Pfam',NULL,'a',NULL,NULL,NULL),('C1-set','Pfam','LRR_8','Pfam',NULL,'a',NULL,NULL,NULL),('PDZ','Pfam','Ras','Pfam',NULL,'a',NULL,NULL,NULL),('Actin','Pfam','SNF2-rel_dom','Pfam',NULL,'a',NULL,NULL,NULL),('C1-set','Pfam','Trypsin','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_2','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('FKBP_C','Pfam','Pkinase','Pfam',NULL,'a',NULL,NULL,NULL),('Histone','Pfam','SET','Pfam',NULL,'a',NULL,NULL,NULL),('AAA','Pfam','ubiquitin','Pfam',NULL,'a',NULL,NULL,NULL),('C1-set','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('C2','Pfam','SH2','Pfam',NULL,'a',NULL,NULL,NULL),('UQ_con','Pfam','WD40','Pfam',NULL,'a',NULL,NULL,NULL),('FKBP_C','Pfam','Metallophos','Pfam',NULL,'a',NULL,NULL,NULL),('LRR_8','Pfam','Lectin_C','Pfam',NULL,'a',NULL,NULL,NULL),('Actin','Pfam','WD40','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_2','Pfam','DEAD','Pfam',NULL,'a',NULL,NULL,NULL),('Sushi','Pfam','VWA','Pfam',NULL,'a',NULL,NULL,NULL),('PK_Tyr_Ser-Thr','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('LRR_8','Pfam','Trypsin','Pfam',NULL,'a',NULL,NULL,NULL),('LRR_8','Pfam','PK_Tyr_Ser-Thr','Pfam',NULL,'a',NULL,NULL,NULL),('7tm_1','Pfam','Pkinase','Pfam',NULL,'a',NULL,NULL,NULL),('Ank_2','Pfam','C1-set','Pfam',NULL,'a',NULL,NULL,NULL),('fn3','Pfam','Lectin_C','Pfam',NULL,'a',NULL,NULL,NULL),('Ig_3','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('EGF','Pfam','Trypsin','Pfam',NULL,'a',NULL,NULL,NULL),('PDZ','Pfam','fn3','Pfam',NULL,'a',NULL,NULL,NULL),('fn3','Pfam','ig','Pfam',NULL,'a',NULL,NULL,NULL),('Ig_3','Pfam','LRR_8','Pfam',NULL,'a',NULL,NULL,NULL),('fn3','Pfam','PDZ','Pfam',NULL,'a',NULL,NULL,NULL),('Metallophos','Pfam','PDZ','Pfam',NULL,'a',NULL,NULL,NULL),('Cadherin','Pfam','Lectin_C','Pfam',NULL,'a',NULL,NULL,NULL),('C1-set','Pfam','VWA','Pfam',NULL,'a',NULL,NULL,NULL),('Actin','Pfam','Lectin_C','Pfam',NULL,'a',NULL,NULL,NULL),('fn3','Pfam','I-set','Pfam',NULL,'a',NULL,NULL,NULL);
UNLOCK TABLES;

--
-- Table structure for table `Domain`
--

DROP TABLE IF EXISTS `Domain`;
CREATE TABLE `Domain` (
  `Name` varchar(30) NOT NULL DEFAULT '',
  `origDB` set('Pfam','SMART','SCOP') NOT NULL DEFAULT '',
  `picFile` varchar(20) DEFAULT NULL,
  `comment` text,
  `Pfam_id` varchar(20) DEFAULT NULL,
  `SCOPLink` varchar(20) DEFAULT NULL,
  `CATHLink` varchar(20) DEFAULT NULL,
  `SMARTLink` varchar(20) DEFAULT NULL,
  `added` date DEFAULT NULL,
  PRIMARY KEY (`Name`,`origDB`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;




DROP TABLE IF EXISTS `GO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;

--
-- Dumping data for table `Domain`
--

LOCK TABLES `Domain` WRITE;
INSERT INTO `Domain` VALUES ('C1-set','Pfam',NULL,NULL,'PF07654.18',NULL,NULL,NULL,'2022-06-17'),('Ras','Pfam',NULL,NULL,'PF00071.25',NULL,NULL,NULL,'2022-06-17'),('Histone','Pfam',NULL,NULL,'PF00125.27',NULL,NULL,NULL,'2022-06-17'),('Pkinase','Pfam',NULL,NULL,'PF00069.28',NULL,NULL,NULL,'2022-06-17'),('Lectin_C','Pfam',NULL,NULL,'PF00059.24',NULL,NULL,NULL,'2022-06-17'),('WD40','Pfam',NULL,NULL,'PF00400.35',NULL,NULL,NULL,'2022-06-17'),('PK_Tyr_Ser-Thr','Pfam',NULL,NULL,'PF07714.20',NULL,NULL,NULL,'2022-06-17'),('AAA','Pfam',NULL,NULL,'PF00004.32',NULL,NULL,NULL,'2022-06-17'),('SH2','Pfam',NULL,NULL,'PF00017.27',NULL,NULL,NULL,'2022-06-17'),('C2','Pfam',NULL,NULL,'PF00168.33',NULL,NULL,NULL,'2022-06-17'),('MHC_I','Pfam',NULL,NULL,'PF00129.21',NULL,NULL,NULL,'2022-06-17'),('Trypsin','Pfam',NULL,NULL,'PF00089.29',NULL,NULL,NULL,'2022-06-17'),('UQ_con','Pfam',NULL,NULL,'PF00179.29',NULL,NULL,NULL,'2022-06-17'),('PDZ','Pfam',NULL,NULL,'PF00595.27',NULL,NULL,NULL,'2022-06-17'),('VWA','Pfam',NULL,NULL,'PF00092.31',NULL,NULL,NULL,'2022-06-17'),('Metallophos','Pfam',NULL,NULL,'PF00149.31',NULL,NULL,NULL,'2022-06-17'),('FKBP_C','Pfam',NULL,NULL,'PF00254.31',NULL,NULL,NULL,'2022-06-17'),('ubiquitin','Pfam',NULL,NULL,'PF00240.26',NULL,NULL,NULL,'2022-06-17'),('7tm_1','Pfam',NULL,NULL,'PF00001.24',NULL,NULL,NULL,'2022-06-17'),('SET','Pfam',NULL,NULL,'PF00856.31',NULL,NULL,NULL,'2022-06-17'),('I-set','Pfam',NULL,NULL,'PF07679.19',NULL,NULL,NULL,'2022-06-17'),('Ank_2','Pfam',NULL,NULL,'PF12796.10',NULL,NULL,NULL,'2022-06-17'),('LRR_8','Pfam',NULL,NULL,'PF13855.9',NULL,NULL,NULL,'2022-06-17'),('Ig_3','Pfam',NULL,NULL,'PF13927.9',NULL,NULL,NULL,'2022-06-17'),('ig','Pfam',NULL,NULL,'PF00047.28',NULL,NULL,NULL,'2022-06-17'),('DEAD','Pfam',NULL,NULL,'PF00270.32',NULL,NULL,NULL,'2022-06-17'),('Helicase_C','Pfam',NULL,NULL,'PF00271.34',NULL,NULL,NULL,'2022-06-17'),('F5_F8_type_C','Pfam',NULL,NULL,'PF00754.28',NULL,NULL,NULL,'2022-06-17'),('EGF','Pfam',NULL,NULL,'PF00008.30',NULL,NULL,NULL,'2022-06-17'),('Ank_4','Pfam',NULL,NULL,'PF13637.9',NULL,NULL,NULL,'2022-06-17'),('TED_complement','Pfam',NULL,NULL,'PF07678.17',NULL,NULL,NULL,'2022-06-17'),('Sushi','Pfam',NULL,NULL,'PF00084.23',NULL,NULL,NULL,'2022-06-17'),('fn3','Pfam',NULL,NULL,'PF00041.24',NULL,NULL,NULL,'2022-06-17'),('ABC_tran','Pfam',NULL,NULL,'PF00005.30',NULL,NULL,NULL,'2022-06-17'),('Ion_trans','Pfam',NULL,NULL,'PF00520.34',NULL,NULL,NULL,'2022-06-17'),('Actin','Pfam',NULL,NULL,'PF00022.22',NULL,NULL,NULL,'2022-06-17'),('Arm','Pfam',NULL,NULL,'PF00514.26',NULL,NULL,NULL,'2022-06-17'),('Cadherin','Pfam',NULL,NULL,'PF00028.20',NULL,NULL,NULL,'2022-06-17'),('SNF2-rel_dom','Pfam',NULL,NULL,'PF00176.26',NULL,NULL,NULL,'2022-06-17'),('Ldl_recept_a','Pfam',NULL,NULL,'PF00057.21',NULL,NULL,NULL,'2022-06-17');
UNLOCK TABLES;
